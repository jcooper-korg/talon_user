# from https://github.com/pimentel/talon_user
from talon import app, ui, clip
from talon.api import lib, ffi
from talon.audio import record, noise
from talon.engine import engine
from talon.voice import Word, Key, Context, Str, press
from talon.skia import Canvas

context = Context('homophones')

homophones = [
    ['1', 'one', 'won'],
    ['2', 'two', 'too', 'to'],
    ['3', 'three'],
    ['4', 'for', 'four', 'fore'],
    ['5', 'five'],
    ['6', 'six'],
    ['7', 'seven'],
    ['8', 'eight'],
    ['9', 'nine'],
    ["I'll", 'aisle', 'isle'],
    ['awful', 'offal'],
    ['ad', 'add'],
    ['ads', 'adds'],
    ['bald', 'balled', 'bawled'],
    ['ball', 'bawl'],
    ['band', 'banned'],
    ['base', 'bass'],
    ['basil', 'basal'],
    ['bear', 'bare'],
    ['break', 'brake'],
    ['breaks', 'brakes'],
    ['bread', 'bred'],
    ['but', 'butt'],
    ['by', 'buy', 'bye'],
    ['cash', 'cache'],
    ['cashed', 'cached'],
    ['Jean', 'gene'],
    ['jeans', 'genes'],
    ['meet', 'meat'],
    ['right', 'write', 'rite'],
    ['pool', 'pull'],
    ["there", "they're", "their"],
    ['where', 'wear'],
]

all_homophones = {}
for l in homophones:
    for word in l:
        all_homophones[word] = l

font = None
active_word_list = None

def run_homophones(canvas):
    if active_word_list is None:
        return

    paint = canvas.paint
    paint.text_size = 22
    paint.color = '000000'
    paint.style = paint.Style.FILL
    canvas.draw_rect(Rect(canvas.x, canvas.y, canvas.width, canvas.height))
    # canvas.draw_rect(canvas.x, canvas.y, canvas.width, canvas.height)

    h = active_word_list
    h_string = ['%d . %s' % (i + 1, h[i]) for i in range(len(h))]
    h_string = '\n'.join(h_string)
    # h_string = h_string.encode('utf8')
    # paint.color = 'ffffff'
    canvas.draw_text(h_string, canvas.x + 20, canvas.y + 20)

pick_context = Context('pick')

def close_homophones():
    pick_context.unload()
    app.unregister('overlay', run_homophones)

def make_selection(m):
    d = int(str(m._words[0]))
    w = active_word_list[d - 1]
    Str(w)(None)
    close_homophones()

def get_selection():
    with clip.capture() as s:
        press('cmd-c', wait=0)
    return s.get()

def draw_homophones(canvas):
    global active_word_list
    print('IN DRAW HOMOPHONES...')
    print(active_word_list)
    if active_word_list is None:
        return

    paint = canvas.paint
    paint.text_size = 22
    paint.color = '000000'
    paint.style = paint.Style.FILL
    canvas.draw_rect(Rect(canvas.x, canvas.y, canvas.width, canvas.height))

    h = active_word_list
    h_string = ['%d . %s' % (i + 1, h[i]) for i in range(len(h))]
    h_string = '\n'.join(h_string)
    paint.color = 'ffffff'
    canvas.draw_text(h_string, canvas.x + 20, canvas.y + 20)


# initialize the overlay
screen = ui.main_screen()
w, h = screen.width / 3, screen.height / 3
panel = canvas.Canvas(w, h, w, h, panel=True)
panel.hide()
panel.register('draw', draw_homophones)

pick_context = Context('pick')

def raise_homophones(m):
    global pick_context
    global active_word_list

    if len(m._words) > 1:
        if hasattr(m, 'dgndictation'):
            word = str(m.dgndictation[0]._words[0])
        else:
            # deal with the 1, 2, ... case
            word = str(m._words[1])
    else:
        word = get_selection()

    if word not in all_homophones:
        app.notify('homophones.py', '"%s" not in homophones list' % word)
        return

    active_word_list = all_homophones[word]
    valid_indices = range(len(active_word_list))
    panel.show()

    keymap = {
        '0': lambda x: close_homophones(),
    }
    keymap.update({'%s' % (i + 1): make_selection for i in valid_indices})
    pick_context.keymap(keymap)
    pick_context.load()

keymap = {
    # Usage:
    # 'homophones word' to look up those homophones.
    # when the list pops up, say appropriate number or zero (leave and do nothing).
    # can also call 'homophones' without any arguments.
    # it will look at the selected text and look that up.
    'homophones [<dgndictation>]': raise_homophones,
    }
keymap.update({'homophones %d' % i : raise_homophones for i in range(10)})

context.keymap(keymap)
